﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace BookCatalog.Models
{
    public class UserAccount : IdentityUser
    {
        //public int Id { get; set; }
        //public string? Nick { get; set; }
        //public string? Password { get; set; }
        //public string? Email { get; set; }
    }
}
